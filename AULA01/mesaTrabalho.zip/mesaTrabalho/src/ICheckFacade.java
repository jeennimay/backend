public interface ICheckFacade {
    public void buscar(String dataPartida, String dataRetorno, String origem, String destino);

}

public class ApiHoteis {

    //Procurar os hoteis disponíveis de acordo com as datas preestabelecidas na cidade de destino

    public void buscarHoteis(String dataEntrada, String dataSaida, String cidade){
        System.out.println("*===============================================*");
        System.out.println("Hoteis encontrados em: " + cidade);
        System.out.println("Entrada: " + dataEntrada + "\nSaída: " + dataSaida);

    }


}

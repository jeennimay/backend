public abstract class Figura {

    abstract double calcularPerimetro();
}

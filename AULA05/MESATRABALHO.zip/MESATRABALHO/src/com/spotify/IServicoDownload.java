package com.spotify;

public interface IServicoDownload {
    void download(Usuario usuario);
}
